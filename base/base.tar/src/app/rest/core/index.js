import auth from "./auth";
const coreAPI=(server)=>{
    auth(server)
}
export default coreAPI